from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import joblib
import pandas as pd
import os
import numpy as np

app = FastAPI(title="AI Travel Assistant API", version="1.0")

# Load model on startup
MODEL_PATH = os.path.join(os.path.dirname(__file__), "models", "destination_recommender_pipeline.pkl")
CLASSES_PATH = os.path.join(os.path.dirname(__file__), "models", "destination_recommender_pipeline_classes.pkl")

pipeline = None
classes = None

@app.on_event("startup")
def load_model():
    global pipeline, classes
    if os.path.exists(MODEL_PATH):
        pipeline = joblib.load(MODEL_PATH)
        if os.path.exists(CLASSES_PATH):
            classes = joblib.load(CLASSES_PATH)
        else:
            classes = pipeline.classes_
        print("Model loaded successfully.")
    else:
        print(f"Warning: Model not found at {MODEL_PATH}. Please run train.py first.")

class RecommendationRequest(BaseModel):
    cust_segment: str
    tour_type: str
    pax: int
    budget_per_person_vnd: float
    channel: str = "Website"
    payment_method: str = "Unknown"
    base_price_vnd: float = None
    total_budget_vnd: float = None

class RecommendationResponse(BaseModel):
    destinations: list[dict]

@app.post("/recommend", response_model=RecommendationResponse)
def recommend_destinations(req: RecommendationRequest):
    if pipeline is None:
        raise HTTPException(status_code=503, detail="Model is not loaded. Please train the model first.")
        
    # Prepare base and total budget if not provided
    base_price = req.base_price_vnd if req.base_price_vnd is not None else req.budget_per_person_vnd
    total_budget = req.total_budget_vnd if req.total_budget_vnd is not None else (req.budget_per_person_vnd * req.pax)
    
    # Create input dataframe
    input_data = pd.DataFrame([{
        'cust_segment': req.cust_segment,
        'tour_type': req.tour_type,
        'pax': req.pax,
        'budget_per_person_vnd': req.budget_per_person_vnd,
        'channel': req.channel,
        'payment_method': req.payment_method,
        'base_price_vnd': base_price,
        'total_budget_vnd': total_budget
    }])
    
    try:
        # Get probability scores for all classes
        proba = pipeline.predict_proba(input_data)[0]
        
        # Combine classes with probabilities
        results = list(zip(classes, proba))
        
        # Sort by probability descending
        results.sort(key=lambda x: x[1], reverse=True)
        
        # Get top 10
        top_10 = results[:10]
        
        # Format response
        destinations = [
            {
                "name": dest_name,
                "score": float(score)
            }
            for dest_name, score in top_10
        ]
        
        return {"destinations": destinations}
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
def health_check():
    return {"status": "ok", "model_loaded": pipeline is not None}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
