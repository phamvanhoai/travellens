import pandas as pd
import numpy as np
import joblib
import os
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier

# Define the features based on requirements
CATEGORICAL_FEATURES = ['cust_segment', 'tour_type', 'channel', 'payment_method']
NUMERICAL_FEATURES = ['pax', 'budget_per_person_vnd', 'base_price_vnd', 'total_budget_vnd']
TARGET = 'destination'

def generate_mock_data(n_samples=1000):
    """Generates mock dataset if CSV is not provided."""
    np.random.seed(42)
    segments = ['Student', 'Young Professional', 'Family', 'Corporate']
    tour_types = ['Beach', 'Cultural', 'Adventure', 'City Break']
    channels = ['Website']
    payments = ['E-wallet', 'Unknown']
    
    # 20 Mock destinations
    destinations = [
        "Hạ Long Bay", "Phú Quốc", "Đà Nẵng", "Hội An", "Nha Trang", 
        "Sapa", "Đà Lạt", "Côn Đảo", "Phong Nha", "Huế",
        "Ninh Bình", "Mũi Né", "Quy Nhơn", "Hà Nội", "Hồ Chí Minh",
        "Phú Yên", "Hà Giang", "Mộc Châu", "Tam Đảo", "Bà Nà Hills"
    ]
    
    data = []
    for _ in range(n_samples):
        segment = np.random.choice(segments)
        tour_type = np.random.choice(tour_types)
        pax = np.random.randint(1, 10)
        budget = np.random.randint(1000000, 10000000)
        channel = np.random.choice(channels)
        payment = np.random.choice(payments)
        
        # Determine destination loosely based on preferences to give the model something to learn
        # It's mock data, so just a bit of correlation
        if tour_type == 'Beach':
            dest = np.random.choice(["Phú Quốc", "Nha Trang", "Mũi Né", "Quy Nhơn", "Côn Đảo"])
        elif tour_type == 'Cultural':
            dest = np.random.choice(["Hội An", "Huế", "Hà Nội", "Ninh Bình"])
        elif tour_type == 'Adventure':
            dest = np.random.choice(["Phong Nha", "Sapa", "Hà Giang", "Mộc Châu"])
        else:
            dest = np.random.choice(destinations)
            
        data.append({
            'cust_segment': segment,
            'tour_type': tour_type,
            'pax': pax,
            'budget_per_person_vnd': budget,
            'channel': channel,
            'payment_method': payment,
            'base_price_vnd': budget,
            'total_budget_vnd': budget * pax,
            'destination': dest
        })
        
    return pd.DataFrame(data)

def train_pipeline(data_path="dataset.csv", model_out_path="models/destination_recommender_pipeline.pkl"):
    print("Loading data...")
    if os.path.exists(data_path):
        df = pd.read_csv(data_path)
        print(f"Loaded existing dataset from {data_path} with {len(df)} rows.")
    else:
        print(f"Dataset {data_path} not found. Generating mock dataset...")
        df = generate_mock_data(2000)
        df.to_csv(data_path, index=False)
        print(f"Saved mock dataset to {data_path}")

    # Prepare features and target
    X = df[CATEGORICAL_FEATURES + NUMERICAL_FEATURES]
    y = df[TARGET]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Preprocessing steps
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), NUMERICAL_FEATURES),
            ('cat', OneHotEncoder(handle_unknown='ignore'), CATEGORICAL_FEATURES)
        ])

    # Model definition
    # Using RandomForest to output probabilities for top N
    clf = RandomForestClassifier(n_estimators=100, random_state=42)

    # Create the pipeline
    pipeline = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('classifier', clf)
    ])

    print("Training pipeline...")
    pipeline.fit(X_train, y_train)

    accuracy = pipeline.score(X_test, y_test)
    print(f"Model trained. Test accuracy: {accuracy:.4f}")

    # Ensure models directory exists
    os.makedirs(os.path.dirname(model_out_path), exist_ok=True)
    
    # Save the pipeline
    joblib.dump(pipeline, model_out_path)
    print(f"Pipeline saved to {model_out_path}")
    
    # Also save the classes_ so we can map probabilities to destination names easily
    joblib.dump(pipeline.classes_, model_out_path.replace('.pkl', '_classes.pkl'))

if __name__ == "__main__":
    # Ensure working directory is correct
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    train_pipeline()
